package com.uped.ejemplos.modelo;

public class Caja {
}
